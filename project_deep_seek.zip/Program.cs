﻿using System;
using System.Threading.Tasks;

/// <summary>
/// Точка входа в приложение.
/// Поддерживает аргументы: "master" для запуска мастера, "worker" для запуска воркера.
/// </summary>
class Program
{
    static async Task Main(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Использование:");
            Console.WriteLine("  dotnet run -- master   - запустить мастер-узел");
            Console.WriteLine("  dotnet run -- worker   - запустить рабочий узел (воркер)");
            Console.WriteLine("  dotnet run -- search <keyword> - выполнить поиск по индексу (после работы мастера)");
            return;
        }

        string command = args[0].ToLower();
        try
        {
            switch (command)
            {
                case "master":
                    await RunMasterAsync();
                    break;

                case "worker":
                    await RunWorkerAsync();
                    break;

                case "search":
                    if (args.Length < 2)
                    {
                        Console.WriteLine("Укажите ключевое слово для поиска: dotnet run -- search <keyword>");
                        return;
                    }
                    RunSearch(args[1]);
                    break;

                default:
                    Console.WriteLine($"Неизвестная команда: {command}");
                    break;
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Критическая ошибка: {ex.Message}");
            Console.WriteLine(ex.StackTrace);
        }
    }

    private static async Task RunMasterAsync()
    {
        using var master = new MasterNode();
        await master.StartAsync();

        // Ожидаем нажатия Ctrl+C или Enter для остановки
        var tcs = new TaskCompletionSource<bool>();
        Console.CancelKeyPress += (sender, e) =>
        {
            e.Cancel = true;
            Logger.Info("Получен сигнал остановки.");
            tcs.TrySetResult(true);
        };

        Console.WriteLine("Нажмите Enter или Ctrl+C для остановки мастера...");
        var enterTask = Task.Run(() => Console.ReadLine());
        await Task.WhenAny(enterTask, tcs.Task);
        await master.StopAsync();

        // После остановки предлагаем поиск по индексу
        Console.WriteLine("\nПоиск по индексу. Введите ключевое слово (или Enter для выхода):");
        while (true)
        {
            string keyword = Console.ReadLine();
            if (string.IsNullOrEmpty(keyword))
                break;

            var results = master.SearchIndex(keyword);
            int count = 0;
            foreach (var url in results)
            {
                Console.WriteLine($"  {url}");
                count++;
            }
            Console.WriteLine($"Найдено страниц: {count}");
            Console.WriteLine("Введите следующее слово или Enter для выхода:");
        }
    }

    private static async Task RunWorkerAsync()
    {
        using var worker = new WorkerNode();
        await worker.StartAsync();
    }

    private static void RunSearch(string keyword)
    {
        // Поиск в автономном режиме не реализован, так как индекс хранится в памяти мастера.
        // Для демонстрации можно сохранять индекс в файл, но это выходит за рамки задания.
        Logger.Warning("Автономный поиск не реализован. Запустите мастер, выполните краулинг, затем поиск будет доступен в консоли мастера.");
    }
}