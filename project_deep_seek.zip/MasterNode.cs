using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

/// <summary>
/// Мастер-узел распределённого веб-краулера.
/// Управляет очередью задач, распределяет их между воркерами,
/// обрабатывает результаты, следит за состоянием воркеров.
/// </summary>
public class MasterNode : IDisposable
{
    // ---------- Конфигурация ----------
    private readonly int _port;
    private readonly int _maxDepth;
    private readonly List<string> _startUrls;

    // ---------- Сетевые компоненты ----------
    private TcpListener _listener;
    private readonly CancellationTokenSource _cts = new CancellationTokenSource();

    // ---------- Пул воркеров ----------
    private readonly ConcurrentDictionary<string, WorkerConnection> _workers = new ConcurrentDictionary<string, WorkerConnection>();

    // ---------- Очередь задач (Dataflow) ----------
    private readonly BufferBlock<TaskItem> _taskBuffer = new BufferBlock<TaskItem>();
    private readonly ActionBlock<CrawlResult> _resultProcessor;

    // ---------- Хранилище индекса ----------
    private readonly IndexStore _indexStore = new IndexStore();

    // ---------- Монитор heartbeat ----------
    private readonly HeartbeatMonitor _heartbeatMonitor = new HeartbeatMonitor();

    // ---------- Счётчики (атомарные) ----------
    private int _totalTasks = 0;
    private int _completedTasks = 0;

    // ---------- Задачи фоновых процессов ----------
    private Task _acceptTask;
    private Task _heartbeatTask;
    private Task _dispatchTask;

    public MasterNode(int port = Configuration.MasterPort,
                      int maxDepth = Configuration.DefaultMaxDepth,
                      List<string> startUrls = null)
    {
        _port = port;
        _maxDepth = maxDepth;
        _startUrls = startUrls ?? Configuration.StartUrls;

        // Настройка пайплайна обработки результатов через TPL Dataflow
        _resultProcessor = new ActionBlock<CrawlResult>(
            async result => await ProcessResult(result),
            new ExecutionDataflowBlockOptions
            {
                MaxDegreeOfParallelism = 4,
                CancellationToken = _cts.Token
            });
    }

    public async Task StartAsync()
    {
        Logger.Info($"Запуск мастер-узла на порту {_port}");
        Logger.Info($"Максимальная глубина: {_maxDepth}");
        Logger.Info($"Стартовые URL: {string.Join(", ", _startUrls)}");

        _listener = new TcpListener(IPAddress.Any, _port);
        _listener.Start();

        _acceptTask = AcceptWorkersAsync();
        _heartbeatTask = MonitorHeartbeatsAsync();
        _dispatchTask = DispatchTasksAsync();

        foreach (var url in _startUrls)
        {
            await AddTaskAsync(new TaskItem { Url = url, Depth = _maxDepth });
        }

        Logger.Info("Мастер запущен. Ожидание подключения воркеров...");
    }

    public async Task StopAsync()
    {
        Logger.Info("Остановка мастера...");
        _cts.Cancel();

        foreach (var kvp in _workers)
        {
            try
            {
                await kvp.Value.SendMessageAsync(new ShutdownMessage());
            }
            catch { /* игнорируем */ }
        }

        await Task.WhenAll(_acceptTask, _heartbeatTask, _dispatchTask);
        _listener?.Stop();

        Logger.Info($"Мастер остановлен. Обработано страниц: {_completedTasks}, всего задач: {_totalTasks}");
    }

    // ---------- Фоновые задачи ----------

    private async Task AcceptWorkersAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                var client = await _listener.AcceptTcpClientAsync();
                var workerId = Guid.NewGuid().ToString();
                var connection = new WorkerConnection(workerId, client, this);
                _workers.TryAdd(workerId, connection);

                Logger.Info($"Воркер {workerId} подключился (адрес: {client.Client.RemoteEndPoint})");
                _ = connection.StartReadingAsync(_cts.Token);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                Logger.Error($"Ошибка при приёме подключения: {ex.Message}");
            }
        }
    }

    private async Task MonitorHeartbeatsAsync()
    {
        var timeout = TimeSpan.FromSeconds(Configuration.HeartbeatTimeoutSeconds);
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(TimeSpan.FromSeconds(Configuration.HeartbeatIntervalSeconds), _cts.Token);

                var deadWorkers = _heartbeatMonitor.GetTimeoutWorkers(timeout);
                foreach (var workerId in deadWorkers)
                {
                    Logger.Warning($"Воркер {workerId} не отвечает. Удаляем и перераспределяем задачи.");

                    if (_workers.TryRemove(workerId, out var connection))
                    {
                        var assignedTasks = connection.GetAssignedTasks();
                        foreach (var task in assignedTasks)
                        {
                            await _taskBuffer.SendAsync(task, _cts.Token);
                            Logger.Info($"Задача {task.Url} возвращена в очередь (воркер {workerId} упал)");
                        }
                        connection.Dispose();
                        _heartbeatMonitor.Remove(workerId);
                    }
                }
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                Logger.Error($"Ошибка в мониторинге heartbeat: {ex.Message}");
            }
        }
    }

    private async Task DispatchTasksAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                var task = await _taskBuffer.ReceiveAsync(_cts.Token);

                var selectedWorker = _workers
                    .Where(kvp => kvp.Value.IsConnected)
                    .OrderBy(kvp => kvp.Value.ActiveTaskCount)
                    .FirstOrDefault();

                if (selectedWorker.Key == null)
                {
                    await _taskBuffer.SendAsync(task, _cts.Token);
                    await Task.Delay(500, _cts.Token);
                    continue;
                }

                var workerId = selectedWorker.Key;
                var connection = selectedWorker.Value;

                await connection.SendMessageAsync(new TaskMessage
                {
                    TaskId = task.Id,
                    Url = task.Url,
                    Depth = task.Depth
                });
                connection.AddAssignedTask(task);
                Interlocked.Increment(ref _totalTasks);

                Logger.Info($"Задача отправлена воркеру {workerId}: {task.Url} (глубина {task.Depth})");
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                Logger.Error($"Ошибка при диспетчеризации задачи: {ex.Message}");
            }
        }
    }

    // ---------- Обработка результата ----------

    private async Task ProcessResult(CrawlResult result)
    {
        try
        {
            if (_workers.TryGetValue(result.WorkerId, out var connection))
            {
                connection.RemoveAssignedTask(result.TaskId);
            }

            Interlocked.Increment(ref _completedTasks);

            if (!result.Success)
            {
                Logger.Warning($"Ошибка при загрузке {result.Url}: {result.Error}");
                return;
            }

            _indexStore.Add(result.Url, result.Content);
            Logger.Info($"Сохранена страница: {result.Url} (размер: {result.Content.Length} символов)");

            // Получаем глубину задачи, чтобы добавить новые ссылки
            var task = connection?.GetAssignedTask(result.TaskId);
            int currentDepth = task?.Depth ?? 0;
            if (currentDepth > 0)
            {
                int newDepth = currentDepth - 1;
                foreach (var link in result.Links)
                {
                    if (!_indexStore.Contains(link))
                    {
                        await AddTaskAsync(new TaskItem { Url = link, Depth = newDepth });
                    }
                }
                Logger.Info($"Добавлено {result.Links.Count} новых ссылок для обхода (глубина {newDepth})");
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Ошибка при обработке результата {result.Url}: {ex.Message}");
        }
    }

    public async Task AddTaskAsync(TaskItem task)
    {
        await _taskBuffer.SendAsync(task, _cts.Token);
    }

    public IEnumerable<string> SearchIndex(string keyword)
    {
        return _indexStore.Search(keyword);
    }

    public void Dispose()
    {
        _cts?.Cancel();
        _listener?.Stop();
        _resultProcessor?.Complete();
    }

    // ---------- Вложенный класс WorkerConnection ----------
    private class WorkerConnection : IDisposable
    {
        private readonly string _workerId;
        private readonly TcpClient _client;
        private readonly MasterNode _master;
        private readonly NetworkStream _stream;
        private readonly StreamReader _reader;
        private readonly StreamWriter _writer;

        private readonly ConcurrentDictionary<Guid, TaskItem> _assignedTasks = new ConcurrentDictionary<Guid, TaskItem>();
        private int _activeTaskCount = 0;

        public bool IsConnected => _client.Connected;
        public int ActiveTaskCount => _activeTaskCount;

        public WorkerConnection(string workerId, TcpClient client, MasterNode master)
        {
            _workerId = workerId;
            _client = client;
            _master = master;
            _stream = client.GetStream();
            _reader = new StreamReader(_stream, Encoding.UTF8);
            _writer = new StreamWriter(_stream, Encoding.UTF8) { AutoFlush = true };
        }

        public async Task StartReadingAsync(CancellationToken cancellationToken)
        {
            try
            {
                while (!cancellationToken.IsCancellationRequested && _client.Connected)
                {
                    string line = await _reader.ReadLineAsync();
                    if (string.IsNullOrEmpty(line)) break;

                    using var doc = JsonDocument.Parse(line);
                    var root = doc.RootElement;
                    if (!root.TryGetProperty("type", out var typeProp)) continue;

                    string type = typeProp.GetString();
                    switch (type)
                    {
                        case "HEARTBEAT_ACK":
                            _master._heartbeatMonitor.Update(_workerId);
                            break;

                        case "RESULT":
                            var result = JsonSerializer.Deserialize<ResultMessage>(line);
                            if (result != null)
                            {
                                var crawlResult = new CrawlResult
                                {
                                    TaskId = result.TaskId,
                                    Url = result.Url,
                                    Success = result.Success,
                                    Content = result.Content,
                                    Links = result.Links,
                                    Error = result.Error,
                                    WorkerId = _workerId
                                };
                                await _master._resultProcessor.SendAsync(crawlResult, cancellationToken);
                            }
                            break;

                        case "ERROR":
                            var error = JsonSerializer.Deserialize<ErrorMessage>(line);
                            Logger.Error($"Воркер {_workerId} сообщил об ошибке: {error?.Text}");
                            break;
                    }
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                Logger.Error($"Ошибка чтения от воркера {_workerId}: {ex.Message}");
            }
            finally
            {
                _master._workers.TryRemove(_workerId, out _);
                _master._heartbeatMonitor.Remove(_workerId);
                Dispose();
            }
        }

        public async Task SendMessageAsync(Message message)
        {
            if (!_client.Connected)
                throw new InvalidOperationException("Соединение закрыто");
            var json = JsonSerializer.Serialize(message);
            await _writer.WriteLineAsync(json);
        }

        public void AddAssignedTask(TaskItem task)
        {
            _assignedTasks.TryAdd(task.Id, task);
            Interlocked.Increment(ref _activeTaskCount);
        }

        public void RemoveAssignedTask(Guid taskId)
        {
            if (_assignedTasks.TryRemove(taskId, out _))
                Interlocked.Decrement(ref _activeTaskCount);
        }

        public TaskItem GetAssignedTask(Guid taskId)
        {
            _assignedTasks.TryGetValue(taskId, out var task);
            return task;
        }

        public List<TaskItem> GetAssignedTasks()
        {
            return _assignedTasks.Values.ToList();
        }

        public void Dispose()
        {
            _stream?.Dispose();
            _reader?.Dispose();
            _writer?.Dispose();
            _client?.Dispose();
        }
    }
}