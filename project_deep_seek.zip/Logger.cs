using System;

/// <summary>
/// Простой потокобезопасный логгер с цветовой дифференциацией уровней.
/// </summary>
public static class Logger
{
    private static readonly object _lock = new object();

    public static void Info(string message)
    {
        lock (_lock)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] {message}");
            Console.ResetColor();
        }
    }

    public static void Warning(string message)
    {
        lock (_lock)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [WARN] {message}");
            Console.ResetColor();
        }
    }

    public static void Error(string message)
    {
        lock (_lock)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [ERRO] {message}");
            Console.ResetColor();
        }
    }
}