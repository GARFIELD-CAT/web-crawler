using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Монитор heartbeat'ов от воркеров.
/// Хранит время последнего полученного heartbeat для каждого воркера.
/// </summary>
public class HeartbeatMonitor
{
    private readonly ConcurrentDictionary<string, DateTime> _lastHeartbeat = new ConcurrentDictionary<string, DateTime>();

    /// <summary>Обновить время последнего heartbeat для воркера.</summary>
    public void Update(string workerId)
    {
        _lastHeartbeat[workerId] = DateTime.UtcNow;
    }

    /// <summary>Удалить воркера из мониторинга.</summary>
    public void Remove(string workerId)
    {
        _lastHeartbeat.TryRemove(workerId, out _);
    }

    /// <summary>
    /// Проверяет, какие воркеры не присылали heartbeat дольше заданного таймаута.
    /// Возвращает список идентификаторов "мёртвых" воркеров.
    /// </summary>
    public List<string> GetTimeoutWorkers(TimeSpan timeout)
    {
        var now = DateTime.UtcNow;
        return _lastHeartbeat
            .Where(kvp => now - kvp.Value > timeout)
            .Select(kvp => kvp.Key)
            .ToList();
    }

    /// <summary>Получить время последнего heartbeat для воркера.</summary>
    public DateTime? GetLast(string workerId)
    {
        if (_lastHeartbeat.TryGetValue(workerId, out var time))
            return time;
        return null;
    }
}