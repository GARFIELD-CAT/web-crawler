using System.Collections.Generic;

/// <summary>
/// Результат обработки одной страницы.
/// </summary>
public class CrawlResult
{
    /// <summary>Идентификатор задачи, к которой относится результат.</summary>
    public Guid TaskId { get; set; }

    /// <summary>URL-адрес страницы.</summary>
    public string Url { get; set; } = string.Empty;

    /// <summary>Успешна ли загрузка и парсинг.</summary>
    public bool Success { get; set; }

    /// <summary>Текстовое содержимое страницы (для индексации).</summary>
    public string Content { get; set; } = string.Empty;

    /// <summary>Список найденных абсолютных ссылок.</summary>
    public List<string> Links { get; set; } = new List<string>();

    /// <summary>Сообщение об ошибке (если Success == false).</summary>
    public string Error { get; set; } = string.Empty;

    /// <summary>Идентификатор воркера, выполнившего задачу.</summary>
    public string WorkerId { get; set; } = string.Empty;
}