using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Реализация хранилища индекса на основе ConcurrentDictionary.
/// Потокобезопасна и допускает параллельный доступ.
/// </summary>
public class IndexStore : IIndexStore
{
    private readonly ConcurrentDictionary<string, string> _store = new ConcurrentDictionary<string, string>();

    public void Add(string url, string content)
    {
        _store.TryAdd(url, content);
    }

    public bool Contains(string url)
    {
        return _store.ContainsKey(url);
    }

    public string Get(string url)
    {
        _store.TryGetValue(url, out var content);
        return content;
    }

    public int Count => _store.Count;

    public IEnumerable<KeyValuePair<string, string>> GetAll()
    {
        return _store.ToList(); // создаём копию для безопасного перечисления
    }

    /// <summary>
    /// Поиск страниц, содержащих заданное ключевое слово (регистронезависимый).
    /// Используется PLINQ для параллельного обхода коллекции.
    /// </summary>
    public IEnumerable<string> Search(string keyword)
    {
        if (string.IsNullOrEmpty(keyword))
            return Enumerable.Empty<string>();

        return _store
            .AsParallel()
            .Where(kvp => kvp.Value.Contains(keyword, System.StringComparison.OrdinalIgnoreCase))
            .Select(kvp => kvp.Key)
            .ToList(); // материализуем, чтобы не было проблем с отложенным выполнением
    }
}