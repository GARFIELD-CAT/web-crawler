using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

/// <summary>
/// Вспомогательный класс для извлечения ссылок и текста из HTML.
/// </summary>
public static class HtmlParser
{
    private static readonly Regex HrefRegex = new Regex(
        @"href\s*=\s*[""'](?<url>.*?)[""']",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    /// <summary>
    /// Извлекает все абсолютные ссылки из HTML-кода.
    /// </summary>
    /// <param name="html">Исходный HTML.</param>
    /// <param name="baseUrl">Базовый URL для преобразования относительных ссылок.</param>
    /// <returns>Список абсолютных ссылок (без якорей, javascript, mailto и т.п.).</returns>
    public static List<string> ExtractLinks(string html, string baseUrl)
    {
        var result = new List<string>();
        if (string.IsNullOrEmpty(html))
            return result;

        var baseUri = new Uri(baseUrl);
        var matches = HrefRegex.Matches(html);

        foreach (Match match in matches)
        {
            string href = match.Groups["url"].Value.Trim();
            if (string.IsNullOrEmpty(href))
                continue;

            // Пропускаем якоря, javascript, mailto и прочие не-HTTP ссылки
            if (href.StartsWith("#") ||
                href.StartsWith("javascript:", StringComparison.OrdinalIgnoreCase) ||
                href.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase) ||
                href.StartsWith("tel:", StringComparison.OrdinalIgnoreCase))
                continue;

            try
            {
                // Преобразуем относительный путь в абсолютный
                if (Uri.TryCreate(href, UriKind.RelativeOrAbsolute, out var uri))
                {
                    if (!uri.IsAbsoluteUri)
                    {
                        uri = new Uri(baseUri, href);
                    }
                    // Оставляем только HTTP/HTTPS
                    if (uri.Scheme == "http" || uri.Scheme == "https")
                    {
                        // Убираем фрагмент (#)
                        var absolute = uri.GetLeftPart(UriPartial.Path);
                        if (!result.Contains(absolute))
                            result.Add(absolute);
                    }
                }
            }
            catch (UriFormatException)
            {
                // Игнорируем некорректные ссылки
            }
        }
        return result;
    }

    /// <summary>
    /// Удаляет HTML-теги и возвращает чистый текст страницы.
    /// </summary>
    public static string ExtractText(string html)
    {
        if (string.IsNullOrEmpty(html))
            return string.Empty;

        // Удаляем скрипты и стили
        var noScript = Regex.Replace(html, @"<script.*?</script>", "", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        var noStyle = Regex.Replace(noScript, @"<style.*?</style>", "", RegexOptions.Singleline | RegexOptions.IgnoreCase);

        // Удаляем все HTML-теги
        var text = Regex.Replace(noStyle, @"<.*?>", " ");
        // Заменяем множественные пробелы на один
        text = Regex.Replace(text, @"\s+", " ");
        return text.Trim();
    }
}