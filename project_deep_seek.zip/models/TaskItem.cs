using System;

/// <summary>
/// Задача для краулера: ссылка и оставшаяся глубина обхода.
/// </summary>
public class TaskItem
{
    /// <summary>Уникальный идентификатор задачи (для отслеживания).</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>URL-адрес для загрузки.</summary>
    public string Url { get; set; } = string.Empty;

    /// <summary>Текущая глубина (0 – не добавлять ссылки).</summary>
    public int Depth { get; set; }

    public override string ToString() => $"[{Depth}] {Url}";
}