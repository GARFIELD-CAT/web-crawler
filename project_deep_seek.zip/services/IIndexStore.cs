using System.Collections.Generic;

/// <summary>
/// Интерфейс хранилища индекса (для возможности замены реализации).
/// </summary>
public interface IIndexStore
{
    void Add(string url, string content);
    bool Contains(string url);
    string Get(string url);
    IEnumerable<KeyValuePair<string, string>> GetAll();
    int Count { get; }
}