using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

/// <summary>
/// Базовый класс для всех сообщений (используется сериализация/десериализация JSON).
/// </summary>
public abstract class Message
{
    [JsonPropertyName("type")]
    public abstract string Type { get; }
}

/// <summary>
/// Команда мастера воркеру: выполнить задачу.
/// </summary>
public class TaskMessage : Message
{
    public override string Type => "TASK";

    [JsonPropertyName("taskId")]
    public Guid TaskId { get; set; }

    [JsonPropertyName("url")]
    public string Url { get; set; } = string.Empty;

    [JsonPropertyName("depth")]
    public int Depth { get; set; }
}

/// <summary>
/// Команда мастера воркеру: отправить heartbeat.
/// </summary>
public class HeartbeatMessage : Message
{
    public override string Type => "HEARTBEAT";
}

/// <summary>
/// Команда мастера воркеру: завершить работу.
/// </summary>
public class ShutdownMessage : Message
{
    public override string Type => "SHUTDOWN";
}

/// <summary>
/// Ответ воркера мастеру: подтверждение heartbeat.
/// </summary>
public class HeartbeatAckMessage : Message
{
    public override string Type => "HEARTBEAT_ACK";
}

/// <summary>
/// Ответ воркера мастеру: результат обработки страницы.
/// </summary>
public class ResultMessage : Message
{
    public override string Type => "RESULT";

    [JsonPropertyName("taskId")]
    public Guid TaskId { get; set; }

    [JsonPropertyName("url")]
    public string Url { get; set; } = string.Empty;

    [JsonPropertyName("success")]
    public bool Success { get; set; }

    [JsonPropertyName("content")]
    public string Content { get; set; } = string.Empty;

    [JsonPropertyName("links")]
    public List<string> Links { get; set; } = new List<string>();

    [JsonPropertyName("error")]
    public string Error { get; set; } = string.Empty;
}

/// <summary>
/// Ответ воркера мастеру: ошибка (например, не удалось распарсить команду).
/// </summary>
public class ErrorMessage : Message
{
    public override string Type => "ERROR";

    [JsonPropertyName("text")]
    public string Text { get; set; } = string.Empty;
}