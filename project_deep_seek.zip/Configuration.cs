using System.Collections.Generic;

/// <summary>
/// Статическая конфигурация приложения.
/// Все параметры вынесены в одно место для удобства настройки.
/// </summary>
public static class Configuration
{
    /// <summary>Порт, на котором мастер ожидает подключения воркеров.</summary>
    public const int MasterPort = 8888;

    /// <summary>IP-адрес мастера (локальный).</summary>
    public const string MasterAddress = "127.0.0.1";

    /// <summary>Интервал отправки heartbeat (в секундах).</summary>
    public const int HeartbeatIntervalSeconds = 5;

    /// <summary>Таймаут без heartbeat, после которого воркер считается мёртвым (в секундах).</summary>
    public const int HeartbeatTimeoutSeconds = 15;

    /// <summary>Максимальная глубина обхода ссылок (по умолчанию 3).</summary>
    public const int DefaultMaxDepth = 3;

    /// <summary>Таймаут для HTTP-запроса (в секундах).</summary>
    public const int HttpTimeoutSeconds = 30;

    /// <summary>Стартовые URL-адреса для краулинга.</summary>
    public static readonly List<string> StartUrls = new List<string>
    {
        "https://books.toscrape.com"
    };
}