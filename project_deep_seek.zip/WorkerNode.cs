using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

/// <summary>
/// Рабочий узел (воркер) распределённого веб-краулера.
/// </summary>
public class WorkerNode : IDisposable
{
    private readonly string _masterAddress;
    private readonly int _masterPort;
    private TcpClient _client;
    private NetworkStream _stream;
    private StreamReader _reader;
    private StreamWriter _writer;
    private readonly HttpClient _httpClient;
    private readonly CancellationTokenSource _cts = new CancellationTokenSource();
    private readonly string _workerId = Guid.NewGuid().ToString();
    private Task _heartbeatTask;

    public WorkerNode(string masterAddress = Configuration.MasterAddress,
                      int masterPort = Configuration.MasterPort)
    {
        _masterAddress = masterAddress;
        _masterPort = masterPort;

        var handler = new HttpClientHandler
        {
            AllowAutoRedirect = true,
            MaxAutomaticRedirections = 5
        };
        _httpClient = new HttpClient(handler)
        {
            Timeout = TimeSpan.FromSeconds(Configuration.HttpTimeoutSeconds)
        };
        _httpClient.DefaultRequestHeaders.Add("User-Agent", "DistributedCrawler/1.0");
    }

    public async Task StartAsync()
    {
        Logger.Info($"Воркер {_workerId} запускается. Подключение к {_masterAddress}:{_masterPort}");

        try
        {
            _client = new TcpClient();
            await _client.ConnectAsync(_masterAddress, _masterPort);
            _stream = _client.GetStream();
            _reader = new StreamReader(_stream, Encoding.UTF8);
            _writer = new StreamWriter(_stream, Encoding.UTF8) { AutoFlush = true };

            Logger.Info($"Воркер {_workerId} подключён к мастеру.");

            _heartbeatTask = SendHeartbeatPeriodicallyAsync();

            while (!_cts.IsCancellationRequested && _client.Connected)
            {
                string line = await _reader.ReadLineAsync();
                if (string.IsNullOrEmpty(line))
                {
                    Logger.Warning("Соединение с мастером разорвано.");
                    break;
                }

                try
                {
                    using var doc = JsonDocument.Parse(line);
                    var root = doc.RootElement;
                    if (!root.TryGetProperty("type", out var typeProp))
                    {
                        Logger.Warning("Некорректное сообщение (нет поля type).");
                        continue;
                    }

                    string type = typeProp.GetString();
                    switch (type)
                    {
                        case "TASK":
                            var task = JsonSerializer.Deserialize<TaskMessage>(line);
                            if (task != null)
                                _ = ProcessTaskAsync(task);
                            break;

                        case "HEARTBEAT":
                            await SendMessageAsync(new HeartbeatAckMessage());
                            break;

                        case "SHUTDOWN":
                            Logger.Info("Получена команда завершения работы.");
                            _cts.Cancel();
                            return;

                        default:
                            Logger.Warning($"Неизвестный тип команды: {type}");
                            break;
                    }
                }
                catch (JsonException jsonEx)
                {
                    Logger.Error($"Ошибка парсинга JSON: {jsonEx.Message}. Строка: {line}");
                    await SendMessageAsync(new ErrorMessage { Text = $"Invalid JSON: {jsonEx.Message}" });
                }
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Ошибка в воркере: {ex.Message}");
        }
        finally
        {
            Dispose();
            Logger.Info($"Воркер {_workerId} остановлен.");
        }
    }

    private async Task ProcessTaskAsync(TaskMessage task)
    {
        var result = new ResultMessage
        {
            TaskId = task.TaskId,
            Url = task.Url,
            Success = false,
            Content = string.Empty,
            Links = new List<string>(),
            Error = string.Empty
        };

        try
        {
            Logger.Info($"Воркер {_workerId} начал обработку {task.Url} (глубина {task.Depth})");

            var response = await _httpClient.GetAsync(task.Url, _cts.Token);
            response.EnsureSuccessStatusCode();
            string html = await response.Content.ReadAsStringAsync();

            string text = HtmlParser.ExtractText(html);
            var links = HtmlParser.ExtractLinks(html, task.Url);

            result.Success = true;
            result.Content = text;
            result.Links = links;
            Logger.Info($"Воркер {_workerId} успешно обработал {task.Url}, найдено ссылок: {links.Count}");
        }
        catch (HttpRequestException httpEx)
        {
            result.Error = $"HTTP ошибка: {httpEx.Message}";
            Logger.Warning($"Воркер {_workerId} не смог загрузить {task.Url}: {result.Error}");
        }
        catch (OperationCanceledException)
        {
            result.Error = "Задача отменена";
            Logger.Warning($"Воркер {_workerId} отменил задачу {task.Url}");
        }
        catch (Exception ex)
        {
            result.Error = $"Ошибка: {ex.Message}";
            Logger.Error($"Воркер {_workerId} ошибка при обработке {task.Url}: {ex.Message}");
        }

        try
        {
            await SendMessageAsync(result);
            Logger.Info($"Воркер {_workerId} отправил результат для {task.Url}");
        }
        catch (Exception ex)
        {
            Logger.Error($"Воркер {_workerId} не смог отправить результат: {ex.Message}");
        }
    }

    private async Task SendHeartbeatPeriodicallyAsync()
    {
        while (!_cts.IsCancellationRequested && _client.Connected)
        {
            try
            {
                await Task.Delay(TimeSpan.FromSeconds(Configuration.HeartbeatIntervalSeconds), _cts.Token);
                await SendMessageAsync(new HeartbeatAckMessage());
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                Logger.Error($"Ошибка отправки heartbeat: {ex.Message}");
            }
        }
    }

    private async Task SendMessageAsync(Message message)
    {
        if (!_client.Connected)
            throw new InvalidOperationException("Соединение с мастером закрыто");

        var json = JsonSerializer.Serialize(message);
        await _writer.WriteLineAsync(json);
    }

    public void Dispose()
    {
        _cts?.Cancel();
        _stream?.Dispose();
        _reader?.Dispose();
        _writer?.Dispose();
        _client?.Dispose();
        _httpClient?.Dispose();
    }
}